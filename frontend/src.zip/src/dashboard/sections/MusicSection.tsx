export default function MusicSection() {
  return (
    <section>
      <h2>Music</h2>
      <p>
        Quản lý nhạc, album, track sẽ nằm ở đây.
      </p>
      <p>
        (Coming soon)
      </p>
    </section>
  );
}
